export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyDXhM4erlv2karhX7jckgSy0nb4cOpRBwE",
    authDomain: "rwc-adv-web-app.firebaseapp.com",
    databaseURL: "https://rwc-adv-web-app.firebaseio.com",
    projectId: "rwc-adv-web-app",
    storageBucket: "rwc-adv-web-app.appspot.com",
    messagingSenderId: "1008848814579"
  }
};